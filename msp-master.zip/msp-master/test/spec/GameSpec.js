 describe("Game", function() {


  beforeEach(function() {

  });

  it("should load the board", function() {

    expect(gameProperties.screenWidth).toEqual(640);

  });

});
