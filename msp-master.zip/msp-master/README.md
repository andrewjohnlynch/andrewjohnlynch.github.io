# msp
this is a tool for playing Meeting Strange People by Tony Eng
forked by Drew on 02/21/16

## Setup
See the [phaser tutorial](http://phaser.io/tutorials/getting-started) for instructions on setting up a web server 
